Распаковать в /usr/local/xupnpd-live/

Запускать так: /usr/local/xupnpd-live/xupnpd-live -d -l 40000 -m ./media/ -c /tmp/