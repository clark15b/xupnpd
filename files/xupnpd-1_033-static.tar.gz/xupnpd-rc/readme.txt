xupnpd-ar231x           Atheros AR231x/AR5312, OpenWrt Barrier Breaker
xupnpd-ar7xxx           Atheros AR7xxx/AR9xxx, OpenWrt Barrier Breaker
xupnpd-bcm2708          Broadcom BCM2708/BCM2835, OpenWrt Barrier Breaker
xupnpd-bcm47xx          Broadcom BCM47xx/BCM53xx, OpenWrt Barrier Breaker (MIPS)
xupnpd-bcm63xx          Broadcom BCM63xx, OpenWrt Barrier Breaker

xupnpd-ar231x-bf        Atheros AR231x, OpenWrt Backfire
xupnpd-ar71xx-bf        Atheros AR71xx, OpenWrt Backfire
xupnpd-bcm947x-bf       Broadcom BCM947x, OpenWrt Backfire

xupnpd-bcm947x-ddwrt    D-Link DIR-320, DD-WRT (mipsel)
