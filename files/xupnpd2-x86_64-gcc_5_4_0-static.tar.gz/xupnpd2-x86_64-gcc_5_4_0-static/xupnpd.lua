-- TVizor
function tvizor_translate_url(url)
    return string.match(utils.fetch(url),";file=(.-)'>")

--    return 'http://176.114.2.10:8080/rys_ekstrim/index.m3u8?token=3b2c32ef77f569f08c1e51fba4c4fe1c'
end

-- Kineskop.tv (10min public)
function kineskop_translate_url(url)
    return string.match(utils.fetch(url),"loadStream%(decodeURIComponent%(getURLParam%('src','(.-)'%)")

--    return 'http://kineskop.tv/hls/211.m3u8?id=_STA543066&watch_time=300&watch_start=1468311638&p=3f162c1f7c1c05e0'
end

function click2stream_translate_url(url)
    local stream_id=string.match(utils.fetch(url),"new%s+Angelcam.player%('player',%s*{%s*id:%s*'(.-)'")

    local req='currentTime=' .. os.date('!%Y-%m-%dT%H%%3A%M%%3A%S.000Z') .. '&offset=-180&dst=0&host=' .. string.match(url,"http://(.+)$") .. '&rtsp=0&sdk=1&streamType=hls&hash_id=' .. stream_id

    local resp=utils.fetch("http://v.angelcam.com/v1/player/" .. stream_id,req)

    local s=string.match(resp,'"streamUrl":"(.-m3u8.-)"')

    local result=string.gsub(s,'\\/','/')

    return result

--    return 'http://e3-eu2.angelcam.com/m1-eu3/3427/playlist.m3u8?token=?????'
end

-- peers.tv
function peers_translate_url(url)
    local s = url .. '?token=' .. string.match(utils.fetch('http://peers.tv'),'playlist%.m3u8%?token=(.-)"')

    return s
end
